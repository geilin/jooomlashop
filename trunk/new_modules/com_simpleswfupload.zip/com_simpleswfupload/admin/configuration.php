<?php
/**
* @Copyright Copyright (C) 2010- Gary Teh Name1price.Com
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/

define("XMLTemplatesLocation" , JPATH_COMPONENT.DS.'workflow_templates');
define("AssetsURLocation" , '/administrator/components/com_simpleswfupload/assets/');

?>