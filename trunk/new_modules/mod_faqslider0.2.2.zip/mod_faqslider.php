<?php
/*
* @name FAQ Slider Module 0.2.2
* @type Joomla 1.5 Plugin
* @author Matt Faulds
* @website http://www.trafalgardesign.com
* @email webmaster@trafalgardesign.com
* @copyright Copyright (C) 2009-2010 Trafalgar Design (Trafalgar Press IOM Ltd.). All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*
* FAQ Slider Plugin is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
*/

defined( '_JEXEC' ) or die( 'Restricted access' );
 
// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );
if(!class_exists('TDPane')) {
	require_once( dirname(__FILE__).DS.'faqslider'.DS.'tdpane.php');
}

$doc =&JFactory::getDocument();

if($params->get('css',1)) {
	$doc->addStyleSheet(JURI::base().'modules/mod_faqslider/faqslider/faqslider.css');
}

require( JModuleHelper::getLayoutPath( 'mod_faqslider' ) );