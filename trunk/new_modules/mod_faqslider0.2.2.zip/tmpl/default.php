<?php
/*
* @name FAQ Slider Module 0.2.2
* @type Joomla 1.5 Plugin
* @author Matt Faulds
* @website http://www.trafalgardesign.com
* @email webmaster@trafalgardesign.com
* @copyright Copyright (C) 2009-2010 Trafalgar Design (Trafalgar Press IOM Ltd.). All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
*
* FAQ Slider Plugin is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$modFaqsliderHelper = new modFaqsliderHelper;
echo $modFaqsliderHelper->modFaqsliderReplacer($params);