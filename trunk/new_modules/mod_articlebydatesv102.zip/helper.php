<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
 
class ModArticleByDates {
    
    public function getArticles($args){
      $db = &JFactory::getDBO();

      $nullDate = $db->getNullDate();
      $date =& JFactory::getDate();
      $now = $date->toMySQL();

      $category_id = $args['category_id'];
      $no_of_items_select = $args['no_of_items_select'];
      $no_of_chars = $args['no_of_chars'];
      $order_by = $args['order_by'];

      $query  = "select cn.id, ca.alias as catalias, cn.alias as conalias, ";
      $query .= "if (length(cn.title)>".$no_of_chars;
      $query .= ",concat(substring(cn.title,1,".$no_of_chars."),'...'), ";
      $query .= "cn.title) as title, ";
      $query .= "created ";
      $query .= "from #__content as cn , ";
      $query .= "#__categories as ca ";
      $query .= "where cn.catid in (".$category_id.")";
      $query .= " and state = 1 and ca.id=cn.catid ";

      $query .= ' and ( publish_up = '.$db->Quote($nullDate).' or publish_up <= '.$db->Quote($now).' )';
      $query .= ' and ( publish_down = '.$db->Quote($nullDate).' or publish_down >= '.$db->Quote($now).' )';
      
      $query .= " order by created ".$order_by;
      $query .= " limit ".$no_of_items_select;

      $db->setQuery($query);
      $items = ($items = $db->loadObjectList())?$items:array();
      return $items;
    }
}
