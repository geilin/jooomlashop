<?php defined('_JEXEC') or die('Restricted access'); // no direct access ?>

<?php
  $config=&JFactory::getConfig();
  $sef=$config->getValue("sef");
?>    

<?php
  // get the parameter values

  $moduleclass_sfx = $params->get('moduleclass_sfx');
  $menuclass_sfx = $params->get('menuclass_sfx');
  $date_group = $params->get('date_group');
  $group_by = $params->get('group_by');
  $date_display_fmt = $params->get('date_display_fmt');
  $date_pre_css = $params->get('date_pre_css');
  $date_post_css = $params->get('date_post_css');
  $no_of_items = $params->get('no_of_items');
?>

<?php 
$pre_article_date="";
foreach ($items as $item) {
	$link  = "index.php?option=com_content&view=article&id=";
	$link .= $item->id.":".$item->conalias;
	$link .= "&catid=".$item->catid.":".$item->catalias;

	if($item_id){
	  $link .= "&Itemid=".$item_id;
	}

	if ($sef==1){
		$link = JRoute::_($link);
	}

  $article_date = $item->created;
  $article_full_date = $article_date;
  
  switch($group_by){
  	case "Y";
  	  $article_date = substr($article_date, 0, 4);
  	  break;
  	case "YM";
  	  $article_date = substr($article_date, 0, 7);
  	  break;
  	case "YMD";
  	  $article_date = substr($article_date, 0, 10);
  	  break;
  }
  
  if ($pre_article_date <> $article_date){
    if($pre_article_date != ""){
    	echo "</ul>";
    }
    if($date_pre_css){
  	  echo $date_pre_css;
    }
  	echo date($date_display_fmt,strtotime($article_full_date));
  	if($date_post_css){
  		echo $date_post_css;
    }
    $pre_article_date=$article_date;
    echo "<ul class='menu".$menuclass_sfx."'>";
  }
  
  echo "<li class='menuitem".$menuclass_sfx."'><a href=".$link."><span>".$item->title."</span></a></li>";

?>

<?php
 }
?>

</ul>
