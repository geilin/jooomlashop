<?php
//no direct access
defined('_JEXEC') or die('Direct Access to this location is not allowed.');
 
// include the helper file
require_once(dirname(__FILE__).DS.'helper.php');

// get a parameter from the module's configuration

$args['category_id'] = $params->get('category_id');
$args['no_of_items_select'] = $params->get('no_of_items_select');
$args['no_of_chars'] = $params->get('no_of_chars');
$args['order_by'] = $params->get('order_by');
       
$items = ModArticleByDates::getArticles($args);

// include the template for display
require(JModuleHelper::getLayoutPath('mod_articlebydates'));
?>
