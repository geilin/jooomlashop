<?php
 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); ?>
<h1><?php echo $this->greeting; ?></h1>

<a href="<?php echo JRoute::_('index.php?option=com_hello&view=hello&id=1');?>" title="">Item one</a>
<a href="<?php echo JRoute::_('index.php?option=com_hello&view=hello&name=nguyen&id=2');?>" title="">Item two</a>
