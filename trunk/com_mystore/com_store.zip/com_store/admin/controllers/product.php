<?php
/**
 * Hello Controller for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http:/docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Hello Hello Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class StoreControllerProduct extends StoreController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'product' );
		JRequest::setVar( 'layout', 'form'  );
		//JRequest::setVar('hidemainmenu', 1);
		$this->__upload_library();
		JHTML::_( 'behavior.mootools' );

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		JRequest::checkToken('request') or jexit( 'Invalid Token' );
		$model = $this->getModel('product');

		if ($model->store($post)) {
			$msg = JText::_( 'Greeting Saved!' );
		} else {
			$msg = JText::_( 'Error Saving Greeting' );
		}

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_store';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		JRequest::checkToken('request') or jexit( 'Invalid Token' );
		$model = $this->getModel('product');
		if(!$model->delete()) {
			$msg = JText::_( 'Error: One or More Greetings Could not be Deleted' );
		} else {
			$msg = JText::_( 'Greeting(s) Deleted' );
		}

		$this->setRedirect( 'index.php?option=com_store', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operation Cancelled' );
		$this->setRedirect( 'index.php?option=com_store', $msg );
	}
	
	
	
	/**
	 *
	 * upload
	 */
	 
	 function upload() {
		jimport('joomla.filesystem.file');
		$upload_dir = JPATH_BASE .DS.'..'.DS .'media'.DS.'com_store'.DS. 'product';
		
		/*echo 'Upload files here';
		echo '<pre>'.print_r($_POST, true).'</pre>';
		echo '<pre>'.print_r($_FILES, true).'</pre>';*/
		
		
		$file 		= JRequest::getVar( 'Filedata', '', 'files', 'array' );
		JFile::upload($file['tmp_name'],  $upload_dir . DS .$file['name']);
		echo json_encode(array('file_name' => $file['name'], 'component_path' => JPATH_COMPONENT));
		

	 
	 }
	 
	 
	 function __upload_library() {
		jimport('joomla.environment.uri' );
		$document =& JFactory::getDocument();
		//get the hosts name
		
		$host = JURI::root(); 
		
		$document->addScript('components/com_store/assets/jquery-1.4.2.min.js');
		$document->addScript('components/com_store/assets/swfobject.js');
		$document->addScriptDeclaration('jQuery.noConflict();');

		$document->addScript('components/com_store/assets/jquery.uploadify.v2.1.4.js');
		$document->addStyleSheet('components/com_store/assets/uploadify.css');
		$session = & JFactory::getSession();

		
		$uploadjs = "
			var host = '".$host."';
			jQuery(document).ready(function() {
			  jQuery('#file_upload').uploadify({

				'uploader'  : 'components/com_store/assets/uploadify.swf',
				'script'    : 'index.php',
				'cancelImg' : 'components/com_store/assets/cancel.png',
				'folder': '/uploads',
				'scriptData':{	
					'option' : 'com_store',
					'controller' : 'product',
					'task' : 'upload',
					'id' : 'product_id',
					'".$session->getName()."' : '".$session->getId()."',
					'format' : 'raw'},
				'auto'      : false,
				'multi': false,
				'removeCompleted' : true,
				'onComplete'  : function(event, ID, fileObj, response, data) { 
					eval('var rp='+response);
					alert(rp.file_name); jQuery('#upload_log').html(response + '<img src=\"'+host+'/media/com_store/product/'+rp.file_name+'\" alt=\"\">'); 
				}
			  });

			});";
		$document->addScriptDeclaration($uploadjs);
	
	 }
}