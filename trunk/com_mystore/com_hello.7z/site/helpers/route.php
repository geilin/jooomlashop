<?php

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Component Helper
jimport('joomla.application.component.helper');

/**
 * QuickFAQ Component Route Helper
 *
 * @static
 * @package		Joomla
 * @subpackage	Content
 * @since 1.5
 */
class HelloHelperRoute
{
	
	/**
	 * @param	int	The route of the faq item
	 */
	function getHelloRoute($id, $catid = 0)
	{
		$needles = array(
			'item'  => (int) $id,
			'category' => (int) $catid
		);

		//Create the link
		$link = 'index.php?option=com_hello&view=hello';

		if($catid) {
			$link .= '&cid='.$catid;
		}
		
		$link .= '&id='. $id;

		if($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item->id;
		};

		return $link;
	}
	
	/**
	 * @param	int	The route of the faq item
	 */
	function getItemRoute($id, $catid = 0)
	{
		$needles = array(
			'item'  => (int) $id,
			'category' => (int) $catid
		);

		//Create the link
		$link = 'index.php?option=com_hello&view=hello';

		if($catid) {
			$link .= '&cid='.$catid;
		}
		
		$link .= '&id='. $id;

		if($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item->id;
		};

		return $link;
	}

	function getCategoryRoute($catid)
	{
		$needles = array(
			'category' => (int) $catid
		);

		//Create the link
		$link = 'index.php?option=com_hello&view=category&cid='.$catid;

		if($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item->id;
		};

		return $link;
	}
	
	function getTagRoute($id)
	{
		$needles = array(
			'tags' => (int) $id
		);

		//Create the link
		$link = 'index.php?option=com_hello&view=tags&id='.$id;

		if($item = self::_findItem($needles)) {
			$link .= '&Itemid='.$item->id;
		};

		return $link;
	}

	function _findItem($needles)
	{
		$component =& JComponentHelper::getComponent('com_hello');

		$menus	= &JApplication::getMenu('site', array());
		$items	= $menus->getItems('componentid', $component->id);
		$user 	= & JFactory::getUser();
		$access = (int)$user->get('aid');

		$match = null;
		$count = 0;		
		
		foreach($needles as $needle => $id)
		{			
			$count++;
			
			foreach($items as $item)
			{
				//fetch menuitems generic of that item
				if ((@$item->query['view'] == $needle) && (@$item->query['id'] == $id)) {
					$match = $item;
					break;
				}
				
				//ensure that only the second part of the array will go through, otherwise $id will seen as $cid
				if($count == 2) {
					//fetch menuitems which might be linked to a category of that item
					if ((@$item->query['view'] == 'category') && (@$item->query['cid'] == $id)) {
						$match = $item;
						break;
					}
				}

			}
			
			if(isset($match)) {
				break;
			}
		}
		
		//no menuitem exists -> return first possible match
		if(empty($match))
		{
			foreach($items as $item)
			{
				if (@$item->published == 1 && @$item->access <= $access && @$item->query['view'] != 'favourites' && @$item->query['layout'] != 'form') {
					$match = $item;
					break;
				}
			}
		}

		return $match;
	}
}
?>
