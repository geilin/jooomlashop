<?php
 
// No direct access
 
defined('_JEXEC') or die('Restricted access'); ?>
<h1><?php echo $this->greeting; ?></h1>

<a href="<?php echo JRoute::_('index.php?option=com_hello&view=hello');?>" title="">Hello world</a>
<a href="<?php echo JRoute::_('index.php?option=com_hello&view=hello&name=nguyen');?>" title="">Visit Nguyen</a>
