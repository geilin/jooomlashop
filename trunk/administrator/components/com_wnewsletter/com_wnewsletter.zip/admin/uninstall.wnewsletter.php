<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
function com_uninstall()
{
?>
<div class="header">Thông tin</div>
<p>
Quá trình gỡ bỏ thành công. Component newsletter được viết trên nền Joomla 1.5.<br />
Tác giả : Lê Văn Hên.<br/>
Công ty : Wamp vn group.<br/>
Website : <a  href="http://wampvn.com">http://wampvn.com</a>
</p>
<?php
}
?>