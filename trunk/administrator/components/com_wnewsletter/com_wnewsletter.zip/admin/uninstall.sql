DROP TABLE IF EXISTS `#__w_newsletter`;
DROP TABLE IF EXISTS `#__w_newsletter_contacts`;
DROP TABLE IF EXISTS `#__w_newsletter_subscribers`;
DROP TABLE IF EXISTS `#__w_newsletter_categories`;