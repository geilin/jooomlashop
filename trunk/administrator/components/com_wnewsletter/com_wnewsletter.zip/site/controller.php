<?php
/**
* @version		1.0
* @package		Component Newsletter
* @copyright	Wampvn Group
* @license		GNU/GPL
* @website          http://wampvn.com
* @description    com newsletter.
*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.controller' );

class NewsLetterController extends JController
{
	function display()
	{
		$document =& JFactory::getDocument();
		$viewName = JRequest::getVar('view', 'newsletter');
		$viewType = $document->getType();
		$view = &$this->getView($viewName, $viewType);

		$view->setLayout('default');
		$view->display();
	}
	
	function subscriber()
	{
		global $option;
		$row =& JTable::getInstance('subscriber', 'Table');
		if (!$row->bind(JRequest::get('post'))) {
			echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
			exit();
		}
		if (!$row->store()) {
			echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
			exit();
		}
		$this->setRedirect('index.php', 'Bạn đã đăng ký nhận email thành công.');
	}
}
?>