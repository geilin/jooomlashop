<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

//ouput html

?>
<div style="margin-bottom:10px;"><?php echo $banner_html; ?></div>