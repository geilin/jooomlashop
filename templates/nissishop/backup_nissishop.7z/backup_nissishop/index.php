<?php

defined( '_JEXEC' ) or die( 'Restricted access' );
include_once (dirname(__FILE__).DS.'/ja_vars.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>">
<head>
<jdoc:include type="head" />
<?php JHTML::_('behavior.mootools'); ?>

<link rel="stylesheet" href="<?php echo $tmpTools->baseurl(); ?>templates/system/css/system.css" type="text/css" />

<link rel="stylesheet" href="<?php echo $tmpTools->baseurl(); ?>templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/template.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/gridsystem.css" type="text/css" />

<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/ja.script.js"></script>
<!--<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/cufon.js"></script>
<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/adobeclean.font.js"></script>-->

<?php if ($tmpTools->getParam('rightCollapsible')): ?>
<script language="javascript" type="text/javascript">
//    Cufon.replace('h1,h2,h3,#header .nav .products .dropdown li a, #header .user .name', {textShadow: '0px -1px #000000', color: '-linear-gradient(#ffffff, #cdcdcd)'});
var rightCollapseDefault='<?php echo $tmpTools->getParam('rightCollapseDefault'); ?>';
var excludeModules='<?php echo $tmpTools->getParam('excludeModules'); ?>';
</script>
<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/ja.rightcol.js"></script>
<?php endif; ?>

<?php  if($this->direction == 'rtl') : ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/template_rtl.css" type="text/css" />

<?php else : ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/menu.css" type="text/css" />
<?php endif; ?>

<?php if ($this->countModules('hornav')): ?>
<?php if ($tmpTools->getParam('horNavType') == 'css'): ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/ja-sosdmenu.css" type="text/css" />
<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/ja.cssmenu.js"></script>
<?php else: ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/css/ja-sosdmenu.css" type="text/css" />
<script language="javascript" type="text/javascript" src="<?php echo $tmpTools->templateurl(); ?>/js/ja.moomenu.js"></script>
<?php endif; ?>
<?php endif; ?>

<?php if ($tmpTools->getParam('theme_header') && $tmpTools->getParam('theme_header')!='-1') : ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/styles/header/<?php echo $tmpTools->getParam('theme_header'); ?>/style.css" type="text/css" />
<?php endif; ?>
<?php /*if ($tmpTools->getParam('theme_background') && $tmpTools->getParam('theme_background')!='-1') : ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/styles/background/<?php echo $tmpTools->getParam('theme_background'); ?>/style.css" type="text/css" />
<?php endif;*/ ?>
<?php if ($tmpTools->getParam('theme_elements') && $tmpTools->getParam('theme_elements')!='-1') : ?>
<link rel="stylesheet" href="<?php echo $tmpTools->templateurl(); ?>/styles/elements/<?php echo $tmpTools->getParam('theme_elements'); ?>/style.css" type="text/css" />
<?php endif; ?>

<!--[if IE 7.0]>
<style type="text/css">
.clearfix {display: inline-block;}
</style>
<![endif]-->
<?php if ($tmpTools->isIE6()): ?>
<!--[if lte IE 6]>
<script type="text/javascript">
var siteurl = '<?php echo $tmpTools->baseurl();?>';

window.addEvent ('load', makeTransBG);
function makeTransBG() {
	fixIEPNG($E('.ja-headermask'), '', '', 1);
	fixIEPNG($E('h1.logo a'));
	fixIEPNG($$('img'));
	fixIEPNG ($$('#ja-mainnav ul.menu li ul'), '', 'scale', 0, 2);
}
</script>
<style type="text/css">
.ja-headermask, h1.logo a, #ja-cssmenu li ul { background-position: -1000px; }
#ja-cssmenu li ul li, #ja-cssmenu li a { background:transparent url(<?php echo $tmpTools->templateurl(); ?>/images/blank.png) no-repeat right;}
.clearfix {height: 1%;}
</style>
<![endif]-->
<?php endif; ?>

<style type="text/css">
#ja-header,#ja-mainnav,#ja-container,#ja-botsl,#ja-footer {width: <?php echo $tmpWidth; ?>;margin: 0 auto;}
#ja-wrapper {min-width: <?php echo $tmpWrapMin; ?>;}
</style>
    
</head>

<body> 
    <?php /*id="bd" class="fs<?php echo $tmpTools->getParam(JA_TOOL_FONT);?> <?php echo $tmpTools->browser();?>"*/?>
    <div id="container_96" class="container_96 clearfix">        
<!-- HEADER -->
        <div class="grid_96 alpha omega">            
<!-- BEGIN: HEADER -->
<div id="header">
	<div>
	<?php
		$siteName = $tmpTools->sitename();
		if ($tmpTools->getParam('logoType')=='image'): ?>
		<h1 class="logo">
			<a href="index.php" title="<?php echo $siteName; ?>"><span><?php echo $siteName; ?></span></a>
		</h1>
	<?php else:
		$logoText = (trim($tmpTools->getParam('logoText'))=='') ? $config->sitename : $tmpTools->getParam('logoText');
		$sloganText = (trim($tmpTools->getParam('sloganText'))=='') ? JText::_('SITE SLOGAN') : $tmpTools->getParam('sloganText');	?>
		<h1 class="logo-text">
			<a href="index.php" title="<?php echo $siteName; ?>"><span><?php echo $logoText; ?></span></a>
		</h1>
		<p class="site-slogan"><?php echo $sloganText;?></p>
	<?php endif; ?>

	<?php /*$tmpTools->genToolMenu(JA_TOOL_FONT, 'png'); */?>

	<?php /*if($this->countModules('user4')) : ?>
		<div id="ja-search">
			<jdoc:include type="modules" name="user4" />
		</div>
	<?php endif; */?>

	</div>
</div>
<!-- END: HEADER -->

<!-- BEGIN: MAIN NAVIGATION -->
<?php if ($this->countModules('hornav')): ?>
<div id="mainnav" class="clearfix">	
	<jdoc:include type="modules" name="hornav" />
</div>
<?php endif; ?>
<!-- END: MAIN NAVIGATION -->            
            
        </div>
        <!-- /HEADER -->
<div class="grid_96 alpha omega">
             
            <div class="grid_20 alpha">
                <?php if ($this->countModules('left')): ?>
                <!-- BEGIN: LEFT COLUMN -->

                <jdoc:include type="modules" name="left" style="xhtml" />
                <!-- END: LEFT COLUMN -->
                <?php endif; ?>
            </div>
                  <!-- MAIN CONTENT -->   
                  <div class="grid_54">
                      <jdoc:include type="message" />
                    <?php if(!$tmpTools->isFrontPage()) : ?>
                    <div id="ja-pathway">
                        <jdoc:include type="module" name="breadcrumbs" />
                    </div>
                    <?php endif ; ?>
                    <?php if($tmpTools->isFrontPage()) : ?>	
                    <div id="selloff">
                        <!-- product selloff -->
                        <image src="<?php echo $tmpTools->templateurl(); ?>/my_images/selloff.jpg" alt="selloff"/>
                        <!-- /product selloff -->
                        <?php if ($this->countModules('selloff')) : ?>
                        <jdoc:include type="module" name="selloff" />
                        <?php endif; ?>
                    </div>
                    <?php endif ; ?>
                      <div id="joomla_component">
                        <jdoc:include type="component" />
                      </div>
                  </div>
                  <!-- /MAIN CONTENT -->
        <div class="grid_20 omega">


        <?php if ($this->countModules('right')): ?>
        <!-- BEGIN: RIGHT COLUMN -->

        <jdoc:include type="modules" name="right" style="jarounded" />

        <!-- END: RIGHT COLUMN -->
        <?php endif; ?>


        </div>
</div>
    <!-- BEGIN:footer -->    
    <div class="grid_96 alpha omega clearfix footer_outer">
        <div class="grid_96 alpha omega footer_wrapper">
            <div id="footnav">
                <jdoc:include type="modules" name="footerlinks" />
            </div>
            <div class="copyright">
                <jdoc:include type="modules" name="footer" />        
            </div>
            <div id="validxhtml">
                <div class="ja-cert">
                    <jdoc:include type="modules" name="syndicate" />
                    <a href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank" title="<?php echo JText::_("CSS Validity");?>" style="text-decoration: none;">
                    <img src="<?php echo $tmpTools->templateurl(); ?>/images/but-css.gif" border="none" alt="<?php echo JText::_("CSS Validity");?>" />
                    </a>
                    <a href="http://validator.w3.org/check/referer" target="_blank" title="<?php echo JText::_("XHTML Validity");?>" style="text-decoration: none;">
                    <img src="<?php echo $tmpTools->templateurl(); ?>/images/but-xhtml10.gif" border="none" alt="<?php echo JText::_("XHTML Validity");?>" />
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- END:footer -->
</div>
<!-- /CONTAINER -->
<jdoc:include type="modules" name="debug" />
</body>
</html>
