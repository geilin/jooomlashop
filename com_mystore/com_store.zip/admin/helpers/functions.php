<?php
require_once JPATH_COMPONENT . DS .'helpers' . DS .'image_lib.php';

function resize_image($opt = array()) {
    $config['image_library']    = 'gd2';
    $config['source_image']     = $opt['file_resize'];
    $config['thumb_marker']     = '';
    //echo $opt['thumb_dir']; exit;
    $config['new_image']        = $opt['thumb_dir'];
    $config['create_thumb']     = TRUE;
    //$config['maintain_ratio']   = FALSE; //TRUE;//default true
    $config['master_dim']       = 'width'; //'width'; //TRUE;
    $config['width']            = $opt['width'];
    $config['height']           = $opt['height'];

    $imglib = new CI_Image_lib($config);
    if ( $imglib->resize() ) {
      return $imglib->dest_image;
    }
    else {
       return $imglib->display_errors(); 
    }
    return FALSE;
}
