<?php
/**
 * Hello Controller for Hello World Component
 * 
 * @package    Joomla.Tutorials
 * @subpackage Components
 * @link http:/docs.joomla.org/Developing_a_Model-View-Controller_Component_-_Part_4
 * @license		GNU/GPL
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Hello Hello Controller
 *
 * @package    Joomla.Tutorials
 * @subpackage Components
 */
class StoreControllerProduct extends StoreController
{
	/**
	 * constructor (registers additional tasks to methods)
	 * @return void
	 */
	function __construct()
	{
		parent::__construct();

		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'product' );
		JRequest::setVar( 'layout', 'form'  );
		//JRequest::setVar('hidemainmenu', 1);
		$this->__upload_library();
		JHTML::_( 'behavior.mootools' );

		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
		JRequest::checkToken('request') or jexit( 'Invalid Token' );
		$model = $this->getModel('product');

		if ($model->store($post)) {
			$msg = JText::_( 'Greeting Saved!' );
		} else {
			$msg = JText::_( 'Error Saving Greeting' );
		}

		// Check the table in so it can be edited.... we are done with it anyway
		$link = 'index.php?option=com_store';
		$this->setRedirect($link, $msg);
	}

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		JRequest::checkToken('request') or jexit( 'Invalid Token' );
		$model = $this->getModel('product');
		if(!$model->delete()) {
			$msg = JText::_( 'Error: One or More Greetings Could not be Deleted' );
		} else {
			$msg = JText::_( 'Greeting(s) Deleted' );
		}

		$this->setRedirect( 'index.php?option=com_store', $msg );
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_( 'Operation Cancelled' );
		$this->setRedirect( 'index.php?option=com_store', $msg );
	}
	
	
	
	/**
	 *
	 * upload
	 */
	 
	 function upload() {
        //http://docs.joomla.org/How_to_use_the_filesystem_package
		jimport('joomla.filesystem.file');        
        require_once JPATH_COMPONENT . DS .'helpers' . DS .'functions.php';      
        
        $base_upload_dir = JPATH_ROOT .  DS . 'media' .DS .'com_store';
    
		$image_dir =   $base_upload_dir . DS . 'images';
		$thumb_dir =   $base_upload_dir . DS . 'thumbs';
		
		$file 		= JRequest::getVar( 'Filedata', '', 'files', 'array' );
		$upload_dest = $image_dir . DS . $file['name'];
        $resize_dest = $thumb_dir  . DS . $file['name'];
        //check file exists
        if ( JFile::exists($upload_dest)) {
            $upload_dest = $image_dir . DS . time(). '_' .  $file['name'];
            $resize_dest = $thumb_dir . DS . time(). '_' .  $file['name'];
        }
        //upload file
        if (!JFile::upload($file['tmp_name'],  $upload_dest)) {            
            echo json_encode(array('error' => true, 'message' => JText::_('Upload file failed')));
            exit;
        }
        
        
        $opt['file_resize'] = $upload_dest ;
        $opt['thumb_dir']   = $thumb_dir ;
        $opt['width']       = 200;
        $opt['height']      = 200;
        
        $thumb = resize_image($opt);     
        
		echo json_encode(array('error' => false, 'file' => $thumb));	 
	 }
	 
	 
	 function __upload_library() {
		jimport('joomla.environment.uri' );
		$document =& JFactory::getDocument();
		//get the hosts name
		
		$host = JURI::root(); 
        $thumb_url = $host . '/media/com_store/thumbs';
		
		$document->addScript('components/com_store/assets/jquery-1.4.2.min.js');
		$document->addScript('components/com_store/assets/swfobject.js');
		$document->addScriptDeclaration('jQuery.noConflict();');

		$document->addScript('components/com_store/assets/jquery.uploadify.v2.1.4.js');
		$document->addStyleSheet('components/com_store/assets/uploadify.css');
		$session = & JFactory::getSession();

		
		$uploadjs = "
			var host = '".$host."';
			jQuery(document).ready(function() {
			  jQuery('#file_upload').uploadify({

				'uploader'  : 'components/com_store/assets/uploadify.swf',
				'script'    : 'index.php',
				'cancelImg' : 'components/com_store/assets/cancel.png',
				'folder': '/uploads',
				'scriptData':{	
					'option' : 'com_store',
					'controller' : 'product',
					'task' : 'upload',
					'id' : 'product_id',
					'".$session->getName()."' : '".$session->getId()."',
					'format' : 'raw'},
				'auto'      : false,
				'multi': false,
				'removeCompleted' : true,
				'onComplete'  : function(event, ID, fileObj, response, data) { 
					//alert(response); return;
                    eval('var data='+response);
				if ( data.error == false ) {
                    jQuery('#upload_log').append('<img src=\"".$thumb_url."/'+data.file+'\"\/>');
                  }
				}
			  });

			});";
        //$('#theDiv').prepend('<img id="theImg" src="theImg.png" />')

		$document->addScriptDeclaration($uploadjs);
        //http://webdesignledger.com/tutorials/19-unique-jquery-tutorials-for-web-developers
        //product galery
        //http://tutorialzine.com/2009/11/beautiful-apple-gallery-slideshow/
        //http://jqueryfordesigners.com/image-loading/
        //http://designm.ag/tutorials/image-rotator-css-jquery/
	 }
}